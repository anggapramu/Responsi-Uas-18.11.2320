﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectProduk
{
    public class Produk
    {
        // TODO: lengkapi property class produk
        public string KodeProduk { get; set; }
        public string NamaProduk { get; set; }
        public string HargaBeli { get; set; }
        public string HargaJual { get; set; }

    }
}
